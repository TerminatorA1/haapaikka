<?php
function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "id13429911_haatuser";
 $dbpass = "KeudaKeskus1!";
 $db = "1d13429911_haat";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);

 $query = "INSERT INTO users(userId, etunimi, sukunimi, lahiosoite, postinro, postitoimipaikka, puhelin, email, password)
 VALUES('1', 'asfd', 'asdf', 'sasdf', 'asf', 'asdf', 'asdf', 'asdf', 'asdf')";
 mysqli_query($db, $query);

 return $conn;
 }

function CloseCon($conn)
 {
 $conn -> close();
 }

?>
