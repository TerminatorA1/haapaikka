-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 17, 2021 at 06:33 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id13429911_haat`
--
CREATE DATABASE IF NOT EXISTS `id13429911_haat` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `id13429911_haat`;

-- --------------------------------------------------------

--
-- Table structure for table `lomaketiedot`
--

CREATE TABLE `lomaketiedot` (
  `lomakeId` int(11) NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tilaus`
--

CREATE TABLE `tilaus` (
  `tilausID` int(11) NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `haapaikka` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tarjoilu` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `esitys` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `aikuinen` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `lapsi` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `lisatieto` varchar(300) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `email` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `etunimi` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `sukunimi` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `lahiosoite` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `postinro` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `postitoimipaikka` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `puhelin` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `haapaikka` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tarjoilu` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `esitys` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `aikuinen` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `lapsi` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `lisatieto` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `otilaus` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `email`, `password`, `etunimi`, `sukunimi`, `lahiosoite`, `postinro`, `postitoimipaikka`, `puhelin`, `haapaikka`, `tarjoilu`, `esitys`, `aikuinen`, `lapsi`, `lisatieto`, `otilaus`) VALUES
(3, 'attevanhatalo@gmail.com', '635ef4877aabda73c0d6fecd280db1cf', 'Atte', 'Vanhatalo', 'Keskikatu 3', '00100', 'Kerava2', '0505220972', 'Bodom', 'Buffet', 'DJ', '33', '5', 'Ei alkoholijuomia', ''),
(4, 'aa', 'aa', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(7, 'atte.vanhatalo@edu.keuda.fi', 'Keuda1', 'Atte', 'V', 'Keskus 2', '00200', 'Helsinki', '99997', '', '', '', '', '', '', ''),
(8, 'atte.vanhatalo@a-link.com', '635ef4877aabda73c0d6fecd280db1cf', 'Atte2', 'V2', 'Keskus 3', '00300', 'Helsinki', '999993', '', '', '', '', '', '', ''),
(9, '1234', '98abe3a28383501f4bfd2d9077820f11', '1', '2', '3', '4', '4', '5', '', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lomaketiedot`
--
ALTER TABLE `lomaketiedot`
  ADD PRIMARY KEY (`lomakeId`);

--
-- Indexes for table `tilaus`
--
ALTER TABLE `tilaus`
  ADD PRIMARY KEY (`tilausID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lomaketiedot`
--
ALTER TABLE `lomaketiedot`
  MODIFY `lomakeId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tilaus`
--
ALTER TABLE `tilaus`
  MODIFY `tilausID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
